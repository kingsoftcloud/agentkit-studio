/** Run `routemind gateway` as a child of the Host, restarting it if it exits unexpectedly. */
import { spawn } from 'node:child_process';

export function gatewayArgs(settings) {
  const url = new URL(settings.gatewayUrl);
  const args = [];
  if (settings.configPath) args.push('--config', settings.configPath);
  args.push('gateway', '--host', url.hostname, '--port', url.port || (url.protocol === 'https:' ? '443' : '80'));
  return args;
}

export function createGateway(settings, { log = console, spawnImpl = spawn, restartDelayMs = 2000, maxRestarts = 5 } = {}) {
  let child, stopped = false, restarts = 0, timer;

  function start() {
    stopped = false;
    child = spawnImpl(settings.command, gatewayArgs(settings), { stdio: ['ignore', 'pipe', 'pipe'], env: process.env });
    child.stdout?.on('data', data => log.debug?.(`routemind gateway: ${String(data).trimEnd()}`));
    child.stderr?.on('data', data => log.debug?.(`routemind gateway: ${String(data).trimEnd()}`));
    child.on('error', error => log.warn?.(`routemind: cannot start "${settings.command}": ${error.message}`));
    child.on('exit', (code, signal) => {
      child = undefined;
      if (stopped) return;
      if (restarts >= maxRestarts) { log.warn?.(`routemind: gateway exited (${code ?? signal}); giving up after ${restarts} restarts`); return; }
      restarts += 1;
      log.warn?.(`routemind: gateway exited (${code ?? signal}); restarting`);
      timer = setTimeout(start, restartDelayMs);
    });
    return child;
  }

  function stop() {
    stopped = true;
    clearTimeout(timer);
    if (child && child.exitCode === null) child.kill('SIGTERM');
    child = undefined;
  }

  return { start, stop, get running() { return Boolean(child); } };
}
