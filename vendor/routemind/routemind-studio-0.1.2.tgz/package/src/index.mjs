/**
 * RouteMind for AgentKit Studio (a DSH plugin).
 *
 * Model calls reach RouteMind through an ordinary Studio model profile whose
 * base URL is the RouteMind gateway and whose model is `auto`, `auto-cost`,
 * `auto-balance` or `auto-quality`. That one profile serves DSH native, Star
 * Harness and Codex (Studio's model proxy turns Codex's Responses calls into
 * Chat Completions); KSXC uses its own enterprise model catalog.
 *
 * This plugin adds what a profile cannot:
 *   - optionally runs the gateway (`routemind gateway`) for the Host's lifetime;
 *   - observes every Auto turn on the `llm/stream` waterfall, whatever the
 *     runtime, and reports its end (completed / truncated / failed / cancelled)
 *     to the gateway, so routing decisions are linked to turn outcomes.
 * It never changes requests or responses and never blocks a turn.
 */
import { createGateway } from './gateway.mjs';
import { createOutcomeObserver } from './observer.mjs';

export const name = 'routemind-studio';
export const inject = [];

export const DEFAULTS = Object.freeze({
  gatewayUrl: 'http://127.0.0.1:8787',
  autoStart: false,
  command: 'routemind',
  configPath: '',
  models: ['auto', 'auto-cost', 'auto-balance', 'auto-quality'],
  reportTimeoutMs: 3000,
  token: '',
});

/** Plugin config wins; then ROUTEMIND_* environment variables; then defaults. */
export function resolveConfig(config = {}, env = process.env) {
  const flag = value => value === true || value === '1' || value === 'true';
  return {
    gatewayUrl: String(config.gatewayUrl || env.ROUTEMIND_GATEWAY_URL || DEFAULTS.gatewayUrl).replace(/\/+$/, ''),
    autoStart: config.autoStart !== undefined ? flag(config.autoStart) : flag(env.ROUTEMIND_AUTOSTART ?? DEFAULTS.autoStart),
    command: config.command || env.ROUTEMIND_COMMAND || DEFAULTS.command,
    configPath: config.configPath || env.ROUTEMIND_CONFIG || DEFAULTS.configPath,
    models: Array.isArray(config.models) && config.models.length ? config.models.map(String) : [...DEFAULTS.models],
    reportTimeoutMs: Number(config.reportTimeoutMs || DEFAULTS.reportTimeoutMs),
    // Gateway token (the gateway's `gateway_token_env`), sent with outcome reports.
    token: String(config.token || env.ROUTEMIND_TOKEN || DEFAULTS.token),
  };
}

export function apply(ctx, config = {}) {
  const settings = resolveConfig(config);
  const log = ctx.logger?.('routemind') ?? console;
  if (settings.autoStart) {
    const gateway = createGateway(settings, { log });
    ctx.effect(() => {
      gateway.start();
      return () => gateway.stop();
    }, 'routemind-studio: gateway process');
  }
  // Studio publishes which llm/stream calls are agent-loop turns; other hosts may not.
  const isAgentLoop = options => {
    const compatibility = typeof ctx.get === 'function' ? ctx.get('studioHostCompatibility') : undefined;
    return typeof compatibility?.isAgentLoopRequest === 'function' ? compatibility.isAgentLoopRequest(options) : undefined;
  };
  const observer = createOutcomeObserver(settings, { log, isAgentLoop });
  // Prepend so the observer wraps the stream every runtime adapter returns.
  ctx.on('llm/stream', (options, next) => observer.handle(options, next), { prepend: true });
}
