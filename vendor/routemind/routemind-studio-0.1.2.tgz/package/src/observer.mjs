/**
 * Observe Auto turns on the DSH `llm/stream` waterfall and report how each ends.
 *
 * DSH turns adapter failures into a terminal `finish` chunk (`reason.kind` is
 * `error` or `aborted`) instead of throwing, so the observer reads that chunk.
 * A `tool-calls` finish means the agent loop continues (DSH native makes one
 * llm/stream call per step); only a turn's last call is reported.
 */
const OUTCOME = { stop: 'completed', 'max-tokens': 'truncated', error: 'failed', aborted: 'cancelled' };

export function textOf(message) {
  const content = message?.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content.filter(part => part?.type === 'text' || part?.kind === 'text')
    .map(part => String(part.text ?? part.value ?? '')).join('');
}

/** The task statement: the session's first user message. */
export function objectiveOf(messages) {
  const first = (Array.isArray(messages) ? messages : []).find(m => m?.role === 'user');
  return first ? textOf(first) : '';
}

/**
 * @param isAgentLoop optional host predicate (Studio's `studioHostCompatibility.isAgentLoopRequest`):
 *   true / false, or undefined when the host cannot tell. Title and other auxiliary requests share the
 *   session id of the turn, so without this check they would be reported as turns.
 */
export function createOutcomeObserver(settings, { log = console, fetchImpl = globalThis.fetch, isAgentLoop = () => undefined } = {}) {
  const autoModels = new Set(settings.models);
  const pending = new Set();

  function isAuto(options) {
    return [options?.model, options?.studioSelectedModel, options?.studioCodexModel].some(m => autoModels.has(String(m ?? '')));
  }

  function isTurn(options) {
    let verdict;
    try { verdict = isAgentLoop(options); } catch { verdict = undefined; }
    if (typeof verdict === 'boolean') return verdict;
    const purpose = options?.purpose ?? options?.metadata?.purpose;
    return purpose === undefined || purpose === null || purpose === 'task';
  }

  function report(options, outcome, failure) {
    const body = {
      session: options?.sessionId ? String(options.sessionId) : undefined,
      objective: objectiveOf(options?.messages),
      runtime: options?.provider ? String(options.provider) : undefined,
      model: String(options?.studioSelectedModel || options?.model || ''),
      outcome,
      ...(failure?.code ? { phase: String(failure.code) } : {}),
    };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), settings.reportTimeoutMs);
    const task = Promise.resolve()
      .then(() => fetchImpl(`${settings.gatewayUrl}/routemind/outcome`, {
        method: 'POST', signal: controller.signal, body: JSON.stringify(body),
      headers: { 'content-type': 'application/json', ...(settings.token ? { authorization: `Bearer ${settings.token}` } : {}) },
      }))
      .then(response => { if (!response.ok) log.warn?.(`routemind: outcome report rejected (HTTP ${response.status})`); })
      .catch(error => log.warn?.(`routemind: outcome report failed: ${error?.message ?? error}`))
      .finally(() => { clearTimeout(timer); pending.delete(task); });
    pending.add(task);
    return task;
  }

  async function* observe(options, upstream) {
    let finish, settled = false;
    try {
      for await (const chunk of upstream) {
        if (chunk?.type === 'finish') finish = chunk.reason;
        yield chunk;
      }
      settled = true;
      const kind = finish?.kind ?? 'stop';
      if (kind !== 'tool-calls') report(options, OUTCOME[kind] ?? 'completed', finish?.failure);
    } catch (error) {
      settled = true;
      report(options, options?.signal?.aborted ? 'cancelled' : 'failed', { code: error?.code });
      throw error;
    } finally {
      // The consumer stopped reading before the stream ended (e.g. the turn was abandoned).
      if (!settled) report(options, 'cancelled');
    }
  }

  return {
    handle(options, next) {
      if (!isAuto(options) || !isTurn(options)) return next();
      const upstream = next();
      if (upstream && typeof upstream.then === 'function') return upstream.then(stream => observe(options, stream));
      return observe(options, upstream);
    },
    /** Wait for in-flight reports (tests and shutdown). */
    settled: () => Promise.allSettled([...pending]),
  };
}
