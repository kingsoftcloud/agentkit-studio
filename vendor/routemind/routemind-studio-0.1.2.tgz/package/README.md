# routemind-studio

让 AgentKit Studio 的每种运行时都能用 RouteMind 自动选模型，并把每个回合的结果回传给 RouteMind。

## 它做什么

| 能力 | 怎么实现 | 覆盖的运行时 |
| --- | --- | --- |
| Auto 选模型 | 一个 Studio 模型配置，地址指向 RouteMind 网关，模型选 `auto` / `auto-cost` / `auto-balance` / `auto-quality` | DSH 原生、Star Harness、Codex |
| 回合结果回传 | 插件挂在 DSH `llm/stream` 最前面，Auto 回合结束时把「完成 / 截断 / 失败 / 取消」发给网关 | DSH 原生、Star Harness、Codex（KSXC 不走 Auto 模型） |
| 网关进程 | 可选：插件随 Host 启停 `routemind gateway`，异常退出自动重启（最多 5 次） | — |

插件不修改请求和响应，回传失败也不会影响回合。

KSXC 使用企业账号自己的模型目录，不经过 Studio 模型配置，所以不支持 Auto。Codex 发出的是 Responses 请求，由 Studio 的模型代理转换成 Chat Completions 后再到达网关。

## 安装

**1. 安装 RouteMind 网关**（Python 3.10+）：

```bash
pip install "git+https://github.com/zhangxiuqi-dev/routemind.git@feat/routing-design"
```

在网关运行的目录准备 `routemind.yaml`，配置上游和三档模型。参考仓库根目录的 `routemind.example.yaml`；星流的接入示例也在里面。

**2. 安装插件**：在 Studio「插件 → 发现」里添加索引源 `integrations/studio-plugin/index.json`（发布到可访问的 HTTPS 地址后填写该地址），然后在列表里安装 **RouteMind for Studio**。索引用 git 源安装，私有仓库需要 DSH 所在机器有该仓库的读取权限；也可以把 `npm pack` 生成的 `.tgz` 上传到对象存储，把索引里的 `source` 改成 `{"type": "tarball", "url": "..."}`。

**3. 配置插件**（插件配置或环境变量，二选一）：

| 配置项 | 环境变量 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `gatewayUrl` | `ROUTEMIND_GATEWAY_URL` | `http://127.0.0.1:8787` | 网关地址 |
| `autoStart` | `ROUTEMIND_AUTOSTART` | `false` | 是否由插件启动网关 |
| `command` | `ROUTEMIND_COMMAND` | `routemind` | 启动网关的命令 |
| `configPath` | `ROUTEMIND_CONFIG` | 空 | 网关配置文件路径 |
| `models` | — | `auto`、`auto-cost`、`auto-balance`、`auto-quality` | 哪些模型名算 Auto 回合 |
| `token` | `ROUTEMIND_TOKEN` | 空 | 网关设置了 `gateway_token_env` 时填同一个令牌；模型配置的 API Key 也填它 |

**4. 添加 Studio 模型配置**：设置 → 模型 → 新增提供商：

- 提供商：自定义（OpenAI 兼容），协议 Chat Completions
- 地址：`http://127.0.0.1:8787/v1`
- API Key：任意非空值（真实密钥配在网关的上游里）
- 模型：点「获取模型列表」，选 `auto`；需要偏向省钱或质量时再加 `auto-cost`、`auto-quality`

之后新建或编辑 Agent 时选这个模型即可，DSH 原生、Star Harness、Codex 都适用。

在支持模型卡的 Studio 中，安装并启用本插件后，对话选模菜单会显示可用的评分和价格，模型目录还可展开详情。停用或卸载后，原有选模和模型连接继续可用。

## 选哪个 Auto

| 模型名 | 优化目标 | 起始模型（按首轮难度） |
| --- | --- | --- |
| `auto` / `auto-balance` | 均衡 | 简单、中等 → cheap；困难 → standard |
| `auto-cost` | 省钱 | 一律 cheap，失败后再升档 |
| `auto-quality` | 质量 | 简单 → standard；中等、困难 → frontier |

升档、降档、预算和故障切换规则见仓库根目录 README 的「路由规则」。

## 查看效果

```bash
routemind models     # 每个模型的实测画像、0–100 评分、实测成本倍数
routemind stats      # 请求数与花费
```

或访问 `GET http://127.0.0.1:8787/routemind/models`。

## 已知限制

- Star Harness 目前不发送 RouteMind 请求头，网关按请求体识别会话和工具失败；harness 发送请求头后，判断会更准确。
- 回传的是**回合**是否正常结束，不等于任务验收通过；验收结果需要宿主另外回传 `resolved`。
- 生成标题等辅助请求不回传：插件优先用 Studio 的 `studioHostCompatibility.isAgentLoopRequest` 判断，宿主不提供时按请求的 `purpose` 判断。
- 需要 DSH `0.2.2-rc.1`（与 Studio 0.0.23 锁定的版本一致）。

## 开发

```bash
npm test
CORDIS_PATH=/path/to/node_modules/@deepseek-ai/cordis npm test   # 额外在真实 Cordis 上下文里验证
```
